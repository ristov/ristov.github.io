Summary: Monitord 1.96 package
Name: monitord
Version: 1.96
Release: 1
BuildArch: noarch
License: GPL
Group: System Environment/Daemons
Source: https://ristov.github.io/monitord/monitord-1.96.tar.gz
Vendor: Risto Vaarandi
BuildRoot: /var/tmp/monitord-%{version}-buildroot
Provides: monitord
Requires: perl

%description
Monitord is a system monitoring daemon for UNIX systems.

%prep
%setup

%install
mkdir -p $RPM_BUILD_ROOT/usr/sbin
cp monitord $RPM_BUILD_ROOT/usr/sbin
mkdir -p $RPM_BUILD_ROOT/usr/lib/systemd/system
mkdir -p $RPM_BUILD_ROOT/etc/sysconfig
cp monitord.conf $RPM_BUILD_ROOT/etc
cp monitord.service $RPM_BUILD_ROOT/usr/lib/systemd/system
cp monitord.sysconfig $RPM_BUILD_ROOT/etc/sysconfig/monitord

%post
%systemd_post monitord.service

%preun
%systemd_preun monitord.service

%postun
%systemd_postun_with_restart monitord.service

%clean
rm -rf $RPM_BUILD_ROOT

%files
%defattr(-,root,root)

%config %attr(644,root,root) /etc/monitord.conf
%config %attr(644,root,root) /etc/sysconfig/monitord

%attr(644,root,root) /usr/lib/systemd/system/monitord.service
%attr(755,root,root) /usr/sbin/monitord

%changelog
* Sat Oct 17 2026 Risto Vaarandi <ristov at users d0t s0urcef0rge d0t net>
- Update to version 1.96

* Tue Nov  1 2016 Risto Vaarandi <ristov at users d0t s0urcef0rge d0t net>
- Update to version 1.95

* Wed Apr 22 2015 Risto Vaarandi <ristov at users d0t s0urcef0rge d0t net>
- Initial release

